<?php 
     $cat = array(); 
     $cat[0] = "news.php"; 
     $cat[Gaestebuch] = "gaestebuch.php";
	 $cat[2] = "blueray.php";
	 $cat[3] = "fehler.php";
?>